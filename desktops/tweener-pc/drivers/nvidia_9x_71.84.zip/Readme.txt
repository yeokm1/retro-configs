================================================================================
NVIDIA Display Driver for Windows 9x            version 4.14.10.7184, 02/24/2005
================================================================================

Operating systems supported
---------------------------
Microsoft Windows 98
Microsoft Windows Millennium Edition (Windows Me)


Adapters supported
------------------
NVIDIA RIVA TNT
NVIDIA RIVA TNT2
NVIDIA RIVA TNT2 Pro
NVIDIA RIVA TNT2 Ultra
NVIDIA Vanta
NVIDIA Vanta LT
NVIDIA RIVA TNT2 Model 64
NVIDIA RIVA TNT2 Model 64 Pro
NVIDIA Aladdin TNT2
NVIDIA GeForce 256
NVIDIA GeForce DDR
NVIDIA Quadro
NVIDIA GeForce2 MX
NVIDIA GeForce2 MX 200
NVIDIA GeForce2 MX 400
NVIDIA Quadro2 MXR
NVIDIA Quadro2 EX
NVIDIA GeForce2 GTS
NVIDIA GeForce2 Pro
NVIDIA GeForce2 Ti
NVIDIA GeForce2 Ultra
NVIDIA GeForce2 Integrated GPU
NVIDIA Quadro2 Pro
NVIDIA GeForce4 MX 420
NVIDIA GeForce4 MX 440
NVIDIA GeForce4 MX 440-SE
NVIDIA GeForce4 MX 460
NVIDIA Quadro NVS
NVIDIA Quadro4 500 XGL
NVIDIA Quadro4 550 XGL
NVIDIA GeForce4 MX Integrated GPU
NVIDIA GeForce4 MX 420 with AGP8X
NVIDIA GeForce4 MX 440 with AGP8X
NVIDIA GeForce4 MX 440SE with AGP8X
NVIDIA Quadro4 NVS with AGP8X
NVIDIA Quadro4 380 XGL
NVIDIA Quadro4 580 XGL
NVIDIA GeForce3
NVIDIA GeForce3 Ti 200
NVIDIA GeForce3 Ti 500
NVIDIA Quadro DCC
NVIDIA GeForce4 Ti 4200
NVIDIA GeForce4 Ti 4400
NVIDIA GeForce4 Ti 4600
NVIDIA GeForce4 Ti 4200 with AGP8X
NVIDIA GeForce4 Ti 4800
NVIDIA GeForce4 Ti 4800 SE
NVIDIA Quadro4 700 XGL
NVIDIA Quadro4 750 XGL
NVIDIA Quadro4 900 XGL
NVIDIA Quadro4 780 XGL
NVIDIA Quadro4 980 XGL
NVIDIA GeForce FX 5800
NVIDIA GeForce FX 5800 Ultra
NVIDIA Quadro FX 1000
NVIDIA Quadro FX 2000


File list
---------
AGARTD.VXD   - AGP support file for Aladdin TNT2
ALIPCIMP.PCI - AGP support file for Aladdin TNT2
DMCPL.EXE    - NVIDIA nView control panel
GENERIC.TVP  - NVIDIA nView generic desktop profile
KEYSTONE.EXE - NVIDIA NVKeystone application
NVAGP.INF    - Windows 9x display driver information file for NVIDIA
               adapters
NVARCH16.DLL - NVIDIA interface layer to NV architecture for 16-bit clients
NVARCH32.DLL - NVIDIA interface layer to NV architecture for 32-bit clients
NVCORE.VXD   - NVIDIA Resource Manager kernel
NVCPL.DLL    - NVIDIA display properties extension
NVCPL.HLP    - NVIDIA display properties extension help file
NVDD32.DLL   - NVIDIA DirectDraw driver
NVDISP.DRV   - NVIDIA display driver
NVIEW.DLL    - NVIDIA nView desktop and window manager
NVIEWIMG.DLL - NVIDIA nView image library
NVINST32.DLL - NVIDIA installation/uninstallation support file
NVMCTRAY.DLL - NVIDIA media center library
NVMINI.VXD   - NVIDIA mini-VDD for VGA virtualization and device Plug-N-Play
NVMODE.DLL   - NVIDIA modeset library
NVOPENGL.DLL - NVIDIA OpenGL driver
NVSHELL.DLL  - NVIDIA desktop explorer
NVTUICPL.CPL - NVIDIA nView control panel
NVWCPLEN.HLP - NVIDIA nView help file
NWIZ.EXE     - NVIDIA nView wizard
README.TXT   - The file you're reading
VGARTD.VXD   - Windows 95 AGP support file

Installation instructions
-------------------------
Windows 98
----------

To prepare for installation of the drivers

1 Start Microsoft Windows 98.

2 Click the Start button, point to Settings, and click Control Panel.

3 Double-click Display, and click the Settings tab.

4 Click Advanced, click the Adapter tab, then click Change.

5 Click Next, click Display a list of all the drivers in a specific location, so
  you can select the driver you want, then click Next.

6 Select Show all Hardware button, then select the Standard display types from
  the Manufacturers list.

7 Select Standard PCI Graphics Adapter (VGA) from the list, then select Next.

8 Click Next to install the driver, then click Finish.

9 Click Apply, then click Close.

10 Click Yes when Windows asks if you wish to restart the computer.



To install the drivers

1 Click the Start button, point to Settings, and click Control Panel.

2 Double-click Display, and click the Settings tab.

3 Click Advanced, click the Adapter tab, then click Change.

4 Click Next, click Display a list of all the drivers in a specific location, so
  you can select the driver you want, then click Next.

5 Click Have Disk, select or type the path to the folder containing the driver
  files, then click OK.

  Windows should find files for your NVIDIA graphics chip.  If Windows cannot
  find the files, check that the path name for the driver files is correct.

6 If Windows found the files, click OK, then click Next.

  Windows copies the files to the hard disk.

7 Click Finish, click Apply, then click Close.

8 Click Yes when Windows asks if you wish to restart the computer.



Windows Millennium Edition
--------------------------

To prepare for installation of the drivers

1 Start Microsoft Windows Millennium Edition.

2 Click the Start button, point to Settings, and click Control Panel.

3 Click Display, and click the Settings tab.

4 Click Advanced, click the Adapter tab, then click Change.

5 Click Specify the location of the driver (Advanced), click Next, click
  Display a list of all the drivers in a specific location, so
  you can select the driver you want, then click Next.

6 Select Show all Hardware button, then select the Standard display types from
  the Manufacturers list.

7 Select Standard PCI Graphics Adapter (VGA) from the list, then select Next.

8 Click Next to install the driver, then click Finish.

9 Click Yes when Windows asks if you wish to restart the computer.



To install the drivers

1 Click the Start button, point to Settings, and click Control Panel.

2 Click Display, and click the Settings tab.

3 Click Advanced, click the Adapter tab, then click Change.

4 Click Specify the location of the driver (Advanced), click Next, click
  Display a list of all the drivers in a specific location, so
  you can select the driver you want, then click Next.

5 Click Have Disk, select or type the path to the folder containing the driver
  files, then click OK.

  Windows should find files for your NVIDIA graphics chip.  If Windows cannot
  find the files, check that the path name for the driver files is correct.

6 If Windows found the files, click OK, then click Next.

  Windows copies the files to the hard disk.

7 Click Finish, then click Yes when Windows asks if you wish to restart the
  computer.


Uninstall instructions
----------------------

To uninstall the drivers

1 Click the Start button, point to Settings, and click Control Panel.

2 Double-click Add/Remove Programs, select NVIDIA Windows 95/98/ME Display
  Drivers, then click Add/Remove.

3 You are then asked about being sure if you want to remove the drivers.
  Click Yes.

4 You are then asked about restarting the system. Click Yes.



Control Freak
-------------

To access Control Freak, NVIDIA's Control Panel applet

1 Click the Start button, point to Settings, and click Control Panel.

2 Double-click Display, and click the tab for your NVIDIA graphics chip.

3 Right click on each option to display information about each setting.


Tips for Users
--------------


Known Issues
------------


Revision history
----------------


================================================================================
Copyright (c) NVIDIA Corporation.                           All rights reserved.
Document number: DR-00008-001
================================================================================
